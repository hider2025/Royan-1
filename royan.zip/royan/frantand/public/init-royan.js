// init-royan.js
(function(){
  // Wait for DOM loaded
  document.addEventListener('DOMContentLoaded', async () => {
    // hide splash if RoyanAuth says ready
    if (window.RoyanAuth) {
      // subscribe to auth changes to update profile
      window.RoyanAuth.onChange((auth)=> {
        // update simple profile placeholders if needed
        try {
          if (auth && auth.user) {
            document.getElementById('profile-name') && (document.getElementById('profile-name').textContent = auth.user.name || 'کاربر');
            document.getElementById('profile-email') && (document.getElementById('profile-email').textContent = auth.user.email || '—');
          }
        } catch(e){}
      });
      // notify ready and hide splash
      try { window.RoyanAuth.notifyReady(); } catch(e){}
    }
    // connect socket if available
    if (window.RoyanSocketClient && window.RoyanAuth) {
      const auth = window.RoyanAuth.getAuthSync ? window.RoyanAuth.getAuthSync() : null;
      window.RoyanSocketClient.connect({ token: auth?.token });
      // handle user-banned event to show suspension UI
      window.RoyanSocketClient.on('user-banned', (payload) => {
        if (payload && payload.until) {
          // persist suspension locally too (client side)
          const untilTs = payload.until;
          localStorage.setItem('roiyan_suspension_v1', JSON.stringify({ until: untilTs, reason: payload.reason || 'نقض قوانین' }));
          // try to call existing UI handler if present
          try { window.RoyanStandalone && window.RoyanStandalone.loadMessages && window.RoyanStandalone.loadMessages(); } catch(e){}
          // page may also have applySuspensionUI function from inline index script
          try { if (window.applySuspensionUI) window.applySuspensionUI({ until: untilTs, reason: payload.reason }); } catch(e){}
        }
      });
    }
    // final safety hide of splash after 3s (in case other hooks not called)
    setTimeout(()=>{ try{ if (window.Royansplash) window.Royansplash.hide(); }catch(e){} }, 3000);
  });
})();
