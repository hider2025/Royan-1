// api-client.js
(function(global){
  let DEFAULT_TIMEOUT = 15000; // ms

  async function request(method, url, body = null, opts = {}) {
    const timeout = opts.timeout || DEFAULT_TIMEOUT;
    const useAuthFetch = (global.RoyanAuth && typeof global.RoyanAuth.fetch === 'function');

    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);

    try {
      const options = {
        method: method.toUpperCase(),
        signal: controller.signal,
        credentials: 'include'
      };
      if (body) {
        if (body instanceof FormData) options.body = body;
        else { options.headers = Object.assign(options.headers||{}, { 'Content-Type': 'application/json' }); options.body = JSON.stringify(body); }
      }
      const fetcher = useAuthFetch ? global.RoyanAuth.fetch : fetch;
      const res = await fetcher(url, options);
      clearTimeout(id);
      if (!res.ok) {
        let text = await res.text().catch(()=>null);
        let json = null;
        try { json = (text ? JSON.parse(text) : null); } catch(e){}
        const err = new Error(json?.message || text || `HTTP ${res.status}`);
        err.status = res.status;
        err.body = json || text;
        throw err;
      }
      const contentType = res.headers.get('content-type') || '';
      if (contentType.includes('application/json')) return await res.json();
      return await res.text();
    } catch (e) {
      clearTimeout(id);
      if (e.name === 'AbortError') throw new Error('timeout');
      throw e;
    }
  }

  const api = {
    get: (u, opts) => request('GET', u, null, opts),
    post: (u, b, opts) => request('POST', u, b, opts),
    put: (u, b, opts) => request('PUT', u, b, opts),
    del: (u, b, opts) => request('DELETE', u, b, opts),
    setDefaultTimeout: (t) => { DEFAULT_TIMEOUT = t; }
  };

  global.RoyanAPI = api;
})(window);
