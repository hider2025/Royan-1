// auth-client.js
// Lightweight auth client for Royan (browser). Exposes window.RoyanAuth.
// Uses fetch to talk to backend API endpoints and localStorage for persistence.
// SECURITY: Prefer httpOnly cookie on server; this is for dev/testing and compatibility.

(function (global) {
  const STORAGE_KEY = 'roiyan_auth_v2';
  let _auth = null; // cached { token, user, expiresAt? }

  // load from storage at startup (sync)
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) _auth = JSON.parse(raw);
  } catch (e) {
    _auth = null;
  }

  // notify listeners
  const listeners = new Set();
  function emitChange() {
    listeners.forEach(fn => { try { fn(_auth); } catch(e){} });
  }

  // helper: persist
  function persistAuth(obj) {
    _auth = obj ? Object.assign({}, obj) : null;
    try {
      if (_auth) localStorage.setItem(STORAGE_KEY, JSON.stringify(_auth));
      else localStorage.removeItem(STORAGE_KEY);
    } catch (e) { /* ignore */ }
    emitChange();
  }

  // wrapper fetch with Authorization header if token present
  async function fetchWithAuth(url, opts = {}) {
    const options = Object.assign({ credentials: 'include' }, opts); // include cookies by default
    options.headers = options.headers || {};
    // if we have token in memory, attach
    if (_auth && _auth.token) {
      options.headers['Authorization'] = 'Bearer ' + _auth.token;
    }
    // set json header if body is an object
    if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
      options.headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(options.body);
    }
    const res = await fetch(url, options);
    // if 401, clear auth (server expired token)
    if (res.status === 401) {
      persistAuth(null);
    }
    return res;
  }

  // public API
  const RoyanAuth = {
    // sync getter (useful from render code)
    getAuthSync: () => _auth ? Object.assign({}, _auth) : null,

    // async getter (ensures token validity; can call /me to verify)
    getAuth: async (opts = { refreshFromServer: false }) => {
      if (!opts.refreshFromServer) return RoyanAuth.getAuthSync();
      try {
        const res = await fetch('/api/auth/me', { credentials: 'include' });
        if (!res.ok) {
          persistAuth(null);
          return null;
        }
        const payload = await res.json();
        const authObj = (_auth ? Object.assign({}, _auth) : {});
        authObj.user = payload.user || authObj.user;
        persistAuth(authObj);
        return authObj;
      } catch (e) {
        return RoyanAuth.getAuthSync();
      }
    },

    // save auth locally: { token, user, expiresAt? }
    saveAuth: async (obj) => {
      const toSave = {
        token: obj.token || null,
        user: obj.user ? Object.assign({}, obj.user) : null,
        expiresAt: obj.expiresAt || null
      };
      persistAuth(toSave);
      return toSave;
    },

    // clear auth (logout client-side)
    clearAuth: async () => {
      try { await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' }); } catch(e){}
      persistAuth(null);
      return true;
    },

    // register via API
    register: async (payload) => {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        credentials: 'include'
      });
      if (!res.ok) {
        const t = await res.text().catch(()=>null);
        throw new Error(t || 'ثبت‌نام موفق نبود');
      }
      const data = await res.json();
      if (data.token) {
        await RoyanAuth.saveAuth({ token: data.token, user: data.user, expiresAt: data.expiresAt });
      }
      emitChange();
      return data;
    },

    // login via API
    login: async (payload) => {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        credentials: 'include'
      });
      if (!res.ok) {
        const text = await res.text().catch(()=>null);
        throw new Error(text || 'ورود موفق نبود');
      }
      const data = await res.json();
      if (data.token) {
        await RoyanAuth.saveAuth({ token: data.token, user: data.user, expiresAt: data.expiresAt });
      }
      emitChange();
      return data;
    },

    // fetch current user from server and update local cache
    me: async () => {
      const res = await fetch('/api/auth/me', { credentials: 'include' });
      if (!res.ok) { persistAuth(null); return null; }
      const data = await res.json();
      const obj = _auth || {};
      obj.user = data.user;
      persistAuth(obj);
      return obj;
    },

    // wrapper for fetch - uses Authorization header if token set
    fetch: fetchWithAuth,

    // register change listener
    onChange: (fn) => {
      if (typeof fn === 'function') listeners.add(fn);
      return () => listeners.delete(fn);
    },

    // helper: mark ready (will hide the splash if available)
    notifyReady: () => { try { if (window.Royansplash) window.Royansplash.hide(); } catch(e){} },

    // expose underlying storage key for debugging/testing
    _STORAGE_KEY: STORAGE_KEY
  };

  global.RoyanAuth = RoyanAuth;

  // Immediately notify listeners with current auth state after tiny delay
  setTimeout(() => emitChange(), 100);

})(window);
