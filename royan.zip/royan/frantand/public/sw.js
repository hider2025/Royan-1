// sw.js — Royan simple service worker
const CACHE_NAME = 'royan-static-v1';

const FILES_TO_CACHE = [
  '/', '/index.html',
  '/favicon.ico'
];

// install -> cache shell
self.addEventListener('install', (ev) => {
  ev.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(FILES_TO_CACHE.map(p => p).filter(Boolean));
    await self.skipWaiting();
  })());
});

// activate -> cleanup
self.addEventListener('activate', (ev) => {
  ev.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.map(k => {
      if (k !== CACHE_NAME) return caches.delete(k);
      return Promise.resolve();
    }));
    await self.clients.claim();
  })());
});

// fetch -> serve from cache, fallback to network, fallback offline page
self.addEventListener('fetch', (ev) => {
  const req = ev.request;
  if (req.method !== 'GET') return;
  ev.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(req);
    if (cached) return cached;
    try {
      const res = await fetch(req);
      if (res && res.status === 200 && req.destination !== 'document') {
        cache.put(req, res.clone());
      }
      return res;
    } catch (err) {
      const fallback = await cache.match('/index.html');
      if (fallback) return fallback;
      return new Response('Offline', { status: 503, statusText: 'Offline' });
    }
  })());
});
