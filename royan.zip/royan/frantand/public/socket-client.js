// socket-client.js
(function(global){
  let socket = null;
  let connected = false;
  let listeners = [];

  function connect(options = {}) {
    if (socket) return socket;
    const url = options.url || (window.location.origin);
    const token = options.token || (global.RoyanAuth && global.RoyanAuth.getAuthSync && global.RoyanAuth.getAuthSync()?.token) || null;
    const opts = {
      path: options.path || '/socket.io',
      transports: ['websocket'],
      withCredentials: true,
      reconnectionAttempts: options.reconnectionAttempts ?? 5,
      auth: {}
    };
    if (token) opts.auth.token = token;
    socket = io(url, opts);
    socket.on('connect', () => {
      connected = true;
      console.log('RoyanSocket connected', socket.id);
    });
    socket.on('disconnect', (reason) => {
      connected = false;
      console.log('RoyanSocket disconnected', reason);
    });
    socket.onAny((ev, payload) => {
      listeners.forEach(l => { try { l(ev, payload); } catch(e){ console.error(e); } });
    });
    return socket;
  }

  function emit(event, data, ack) {
    if (!socket) return null;
    return socket.emit(event, data, ack);
  }

  function on(event, cb) {
    if (!socket) return;
    socket.on(event, cb);
  }

  function off(event, cb) {
    if (!socket) return;
    socket.off(event, cb);
  }

  function disconnect() {
    if (!socket) return;
    socket.disconnect();
    socket = null;
    connected = false;
  }

  function isConnected() { return connected; }

  function addListener(fn) { listeners.push(fn); return () => { listeners = listeners.filter(x => x !== fn); }; }

  global.RoyanSocketClient = {
    connect, emit, on, off, disconnect, isConnected, addListener
  };
})(window);
