<?php
require_once 'config.php';

// Simple router
$request_uri = $_SERVER['REQUEST_URI'];
$path = parse_url($request_uri, PHP_URL_PATH);
$path = str_replace('/royan-backend-php', '', $path); // Adjust for subdirectory

header('Content-Type: application/json');

if ($path === '/' || $path === '') {
    echo json_encode([
        'status' => 'success',
        'message' => 'Royan Messenger API',
        'version' => APP_VERSION
    ], JSON_UNESCAPED_UNICODE);
} else {
    http_response_code(404);
    echo json_encode([
        'status' => 'error',
        'message' => 'Endpoint پیدا نشد'
    ], JSON_UNESCAPED_UNICODE);
}
?>