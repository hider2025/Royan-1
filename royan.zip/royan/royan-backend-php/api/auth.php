<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $auth = new Auth();

    if (isset($_GET['action'])) {
        switch ($_GET['action']) {
            case 'register':
                if (!isset($input['username']) || !isset($input['name']) || !isset($input['email']) || !isset($input['password'])) {
                    sendResponse(400, 'اطلاعات لازم ارسال نشده است');
                }

                $result = $auth->register(
                    $input['username'],
                    $input['name'],
                    $input['email'],
                    $input['password']
                );

                if ($result['success']) {
                    sendResponse(201, 'ثبت‌نام موفقیت‌آمیز بود', $result);
                } else {
                    sendResponse(400, $result['message']);
                }
                break;

            case 'login':
                if (!isset($input['username']) || !isset($input['password'])) {
                    sendResponse(400, 'نام کاربری و رمز عبور الزامی است');
                }

                $result = $auth->login($input['username'], $input['password']);

                if ($result['success']) {
                    sendResponse(200, 'ورود موفقیت‌آمیز بود', $result);
                } else {
                    sendResponse(401, $result['message']);
                }
                break;

            case 'logout':
                $token = getBearerToken();
                $user_id = $auth->verifyToken($token);
                
                if (!$user_id) {
                    sendResponse(401, 'توکن معتبر نیست');
                }

                $result = $auth->logout($user_id);
                sendResponse(200, $result['message']);
                break;

            default:
                sendResponse(400, 'Action نامعتبر');
        }
    } else {
        sendResponse(400, 'Action مشخص نشده است');
    }
} else {
    sendResponse(405, 'Method مجاز نیست');
}
?>