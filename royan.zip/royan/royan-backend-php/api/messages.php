<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

$auth = new Auth();
$token = getBearerToken();
$user_id = $auth->verifyToken($token);

if (!$user_id) {
    sendResponse(401, 'لطفاً وارد سیستم شوید');
}

$db = (new Database())->getConnection();

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        // Get messages for a group
        if (isset($_GET['group_id'])) {
            $group_id = $_GET['group_id'];
            $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
            $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 50;
            $offset = ($page - 1) * $limit;

            // Check if user is member of the group
            $member_check = $db->fetch(
                "SELECT id FROM group_members WHERE group_id = ? AND user_id = ?",
                [$group_id, $user_id]
            );

            if (!$member_check) {
                sendResponse(403, 'شما عضو این گروه نیستید');
            }

            // Get messages
            $messages = $db->fetchAll("
                SELECT m.*, u.username, u.name, u.avatar, u.role 
                FROM messages m 
                JOIN users u ON m.sender_id = u.id 
                WHERE m.group_id = ? AND m.deleted = 0 
                ORDER BY m.created_at DESC 
                LIMIT ? OFFSET ?
            ", [$group_id, $limit, $offset]);

            // Get total count
            $total = $db->fetch("SELECT COUNT(*) as count FROM messages WHERE group_id = ? AND deleted = 0", [$group_id]);

            sendResponse(200, 'پیام‌ها دریافت شد', [
                'messages' => array_reverse($messages), // Return in chronological order
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => $total['count'],
                    'pages' => ceil($total['count'] / $limit)
                ]
            ]);
        }
        break;

    case 'POST':
        // Send new message
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($input['group_id']) || (!isset($input['content']) && !isset($input['file_url']))) {
            sendResponse(400, 'اطلاعات لازم ارسال نشده است');
        }

        // Check group membership
        $member_check = $db->fetch(
            "SELECT id FROM group_members WHERE group_id = ? AND user_id = ?",
            [$input['group_id'], $user_id]
        );

        if (!$member_check) {
            sendResponse(403, 'شما عضو این گروه نیستید');
        }

        // Insert message
        $sql = "INSERT INTO messages (group_id, sender_id, content, type, file_url, file_name, file_size, duration, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $type = isset($input['file_url']) ? ($input['type'] ?? 'file') : 'text';
        
        $db->query($sql, [
            $input['group_id'],
            $user_id,
            $input['content'] ?? null,
            $type,
            $input['file_url'] ?? null,
            $input['file_name'] ?? null,
            $input['file_size'] ?? null,
            $input['duration'] ?? null
        ]);

        $message_id = $db->lastInsertId();

        // Get the created message with user info
        $message = $db->fetch("
            SELECT m.*, u.username, u.name, u.avatar, u.role 
            FROM messages m 
            JOIN users u ON m.sender_id = u.id 
            WHERE m.id = ?
        ", [$message_id]);

        sendResponse(201, 'پیام ارسال شد', ['message' => $message]);
        break;

    case 'PUT':
        // Edit message
        if (isset($_GET['message_id'])) {
            $input = json_decode(file_get_contents('php://input'), true);
            $message_id = $_GET['message_id'];

            if (!isset($input['content'])) {
                sendResponse(400, 'محتوی پیام الزامی است');
            }

            // Check if user owns the message
            $message = $db->fetch(
                "SELECT id FROM messages WHERE id = ? AND sender_id = ? AND deleted = 0",
                [$message_id, $user_id]
            );

            if (!$message) {
                sendResponse(404, 'پیام یافت نشد');
            }

            // Update message
            $db->query(
                "UPDATE messages SET content = ?, edited = 1, updated_at = NOW() WHERE id = ?",
                [$input['content'], $message_id]
            );

            // Get updated message
            $updated_message = $db->fetch("
                SELECT m.*, u.username, u.name, u.avatar, u.role 
                FROM messages m 
                JOIN users u ON m.sender_id = u.id 
                WHERE m.id = ?
            ", [$message_id]);

            sendResponse(200, 'پیام ویرایش شد', ['message' => $updated_message]);
        }
        break;

    case 'DELETE':
        // Delete message
        if (isset($_GET['message_id'])) {
            $message_id = $_GET['message_id'];

            // Check if user owns the message or is admin
            $message = $db->fetch("
                SELECT m.*, u.role 
                FROM messages m 
                JOIN users u ON m.sender_id = u.id 
                WHERE m.id = ? AND (m.sender_id = ? OR u.role = 'admin')
            ", [$message_id, $user_id]);

            if (!$message) {
                sendResponse(404, 'پیام یافت نشد');
            }

            // Soft delete
            $db->query("UPDATE messages SET deleted = 1, updated_at = NOW() WHERE id = ?", [$message_id]);

            sendResponse(200, 'پیام حذف شد');
        }
        break;

    default:
        sendResponse(405, 'Method مجاز نیست');
}
?>