<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/upload.php';

header('Content-Type: application/json');

$auth = new Auth();
$token = getBearerToken();
$user_id = $auth->verifyToken($token);

if (!$user_id) {
    sendResponse(401, 'لطفاً وارد سیستم شوید');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['file'])) {
        $file = $_FILES['file'];
        $upload = new FileUpload();
        
        $result = $upload->handleUpload($file);
        
        if ($result['success']) {
            sendResponse(200, 'فایل با موفقیت آپلود شد', $result);
        } else {
            sendResponse(400, $result['message']);
        }
    } else {
        sendResponse(400, 'هیچ فایلی ارسال نشده است');
    }
} else {
    sendResponse(405, 'Method مجاز نیست');
}
?>