<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

$auth = new Auth();
$token = getBearerToken();
$user_id = $auth->verifyToken($token);

if (!$user_id) {
    sendResponse(401, 'لطفاً وارد سیستم شوید');
}

$db = (new Database())->getConnection();

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        // Get user's groups
        if (!isset($_GET['action'])) {
            $groups = $db->fetchAll("
                SELECT g.*, gm.role, u.username as created_by_username 
                FROM groups g 
                JOIN group_members gm ON g.id = gm.group_id 
                JOIN users u ON g.created_by = u.id 
                WHERE gm.user_id = ? 
                ORDER BY g.created_at DESC
            ", [$user_id]);

            sendResponse(200, 'گروه‌ها دریافت شد', ['groups' => $groups]);
        }

        // Get group details
        if ($_GET['action'] === 'details' && isset($_GET['group_id'])) {
            $group_id = $_GET['group_id'];
            
            $group = $db->fetch("
                SELECT g.*, u.username as created_by_username, 
                       COUNT(gm.id) as member_count
                FROM groups g 
                JOIN users u ON g.created_by = u.id 
                LEFT JOIN group_members gm ON g.id = gm.group_id 
                WHERE g.id = ?
                GROUP BY g.id
            ", [$group_id]);

            if (!$group) {
                sendResponse(404, 'گروه یافت نشد');
            }

            // Get group members
            $members = $db->fetchAll("
                SELECT u.id, u.username, u.name, u.avatar, u.role, u.online, 
                       gm.role as group_role, gm.joined_at 
                FROM group_members gm 
                JOIN users u ON gm.user_id = u.id 
                WHERE gm.group_id = ? 
                ORDER BY 
                    CASE gm.role 
                        WHEN 'owner' THEN 1 
                        WHEN 'admin' THEN 2 
                        ELSE 3 
                    END,
                    gm.joined_at
            ", [$group_id]);

            $group['members'] = $members;
            sendResponse(200, 'اطلاعات گروه دریافت شد', ['group' => $group]);
        }
        break;

    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($input['name'])) {
            sendResponse(400, 'نام گروه الزامی است');
        }

        // Create new group
        $db->query(
            "INSERT INTO groups (name, description, avatar, created_by, is_public, settings) 
             VALUES (?, ?, ?, ?, ?, ?)",
            [
                $input['name'],
                $input['description'] ?? null,
                $input['avatar'] ?? null,
                $user_id,
                $input['is_public'] ?? true,
                json_encode($input['settings'] ?? ['allowInvites' => true, 'allowFileSharing' => true])
            ]
        );

        $group_id = $db->lastInsertId();

        // Add creator as owner
        $db->query(
            "INSERT INTO group_members (group_id, user_id, role) VALUES (?, ?, 'owner')",
            [$group_id, $user_id]
        );

        // Get created group
        $group = $db->fetch("
            SELECT g.*, u.username as created_by_username 
            FROM groups g 
            JOIN users u ON g.created_by = u.id 
            WHERE g.id = ?
        ", [$group_id]);

        sendResponse(201, 'گروه با موفقیت ایجاد شد', ['group' => $group]);
        break;

    case 'PUT':
        if (isset($_GET['group_id'])) {
            $group_id = $_GET['group_id'];
            $input = json_decode(file_get_contents('php://input'), true);

            // Check if user is owner/admin of the group
            $member = $db->fetch("
                SELECT role FROM group_members 
                WHERE group_id = ? AND user_id = ? AND role IN ('owner', 'admin')
            ", [$group_id, $user_id]);

            if (!$member) {
                sendResponse(403, 'شما دسترسی لازم برای ویرایش این گروه را ندارید');
            }

            // Update group
            $update_fields = [];
            $params = [];

            if (isset($input['name'])) {
                $update_fields[] = "name = ?";
                $params[] = $input['name'];
            }

            if (isset($input['description'])) {
                $update_fields[] = "description = ?";
                $params[] = $input['description'];
            }

            if (isset($input['avatar'])) {
                $update_fields[] = "avatar = ?";
                $params[] = $input['avatar'];
            }

            if (isset($input['settings'])) {
                $update_fields[] = "settings = ?";
                $params[] = json_encode($input['settings']);
            }

            if (empty($update_fields)) {
                sendResponse(400, 'هیچ فیلدی برای به‌روزرسانی ارسال نشده است');
            }

            $params[] = $group_id;
            $sql = "UPDATE groups SET " . implode(', ', $update_fields) . ", updated_at = NOW() WHERE id = ?";
            $db->query($sql, $params);

            sendResponse(200, 'گروه با موفقیت به‌روزرسانی شد');
        }
        break;

    case 'DELETE':
        if (isset($_GET['group_id'])) {
            $group_id = $_GET['group_id'];

            // Check if user is owner of the group
            $member = $db->fetch("
                SELECT role FROM group_members 
                WHERE group_id = ? AND user_id = ? AND role = 'owner'
            ", [$group_id, $user_id]);

            if (!$member) {
                sendResponse(403, 'فقط سازنده گروه می‌تواند آن را حذف کند');
            }

            // Delete group (cascade will handle members and messages)
            $db->query("DELETE FROM groups WHERE id = ?", [$group_id]);

            sendResponse(200, 'گروه با موفقیت حذف شد');
        }
        break;

    default:
        sendResponse(405, 'Method مجاز نیست');
}
?>