<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

$auth = new Auth();
$token = getBearerToken();
$user_id = $auth->verifyToken($token);

if (!$user_id) {
    sendResponse(401, 'لطفاً وارد سیستم شوید');
}

$db = (new Database())->getConnection();

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        // Get active stories
        $stories = $db->fetchAll("
            SELECT s.*, u.username, u.name, u.avatar 
            FROM stories s 
            JOIN users u ON s.user_id = u.id 
            WHERE s.expires_at > NOW() 
            ORDER BY s.created_at DESC
        ");

        // Group stories by user
        $grouped_stories = [];
        foreach ($stories as $story) {
            $user_id = $story['user_id'];
            if (!isset($grouped_stories[$user_id])) {
                $grouped_stories[$user_id] = [
                    'user' => [
                        'id' => $story['user_id'],
                        'username' => $story['username'],
                        'name' => $story['name'],
                        'avatar' => $story['avatar']
                    ],
                    'stories' => []
                ];
            }
            $grouped_stories[$user_id]['stories'][] = [
                'id' => $story['id'],
                'media_url' => $story['media_url'],
                'created_at' => $story['created_at'],
                'expires_at' => $story['expires_at']
            ];
        }

        sendResponse(200, 'استوری‌ها دریافت شد', ['stories' => array_values($grouped_stories)]);
        break;

    case 'POST':
        // Create new story
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($input['media_url'])) {
            sendResponse(400, 'آدرس فایل مدیا الزامی است');
        }

        // Set expiration (24 hours from now)
        $expires_at = date('Y-m-d H:i:s', strtotime('+24 hours'));

        $db->query("
            INSERT INTO stories (user_id, media_url, expires_at) 
            VALUES (?, ?, ?)
        ", [$user_id, $input['media_url'], $expires_at]);

        $story_id = $db->lastInsertId();

        // Get created story
        $story = $db->fetch("
            SELECT s.*, u.username, u.name, u.avatar 
            FROM stories s 
            JOIN users u ON s.user_id = u.id 
            WHERE s.id = ?
        ", [$story_id]);

        sendResponse(201, 'استوری با موفقیت ایجاد شد', ['story' => $story]);
        break;

    case 'DELETE':
        // Delete story
        if (isset($_GET['story_id'])) {
            $story_id = $_GET['story_id'];

            // Check if user owns the story
            $story = $db->fetch("
                SELECT id FROM stories 
                WHERE id = ? AND user_id = ?
            ", [$story_id, $user_id]);

            if (!$story) {
                sendResponse(404, 'استوری یافت نشد');
            }

            $db->query("DELETE FROM stories WHERE id = ?", [$story_id]);

            sendResponse(200, 'استوری حذف شد');
        }
        break;

    default:
        sendResponse(405, 'Method مجاز نیست');
}
?>