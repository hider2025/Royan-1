<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

$auth = new Auth();
$token = getBearerToken();
$user_id = $auth->verifyToken($token);

if (!$user_id) {
    sendResponse(401, 'لطفاً وارد سیستم شوید');
}

$db = (new Database())->getConnection();

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        // Get user profile
        if (!isset($_GET['action'])) {
            $user = $db->fetch("
                SELECT id, username, name, avatar, role, online, last_seen, created_at 
                FROM users WHERE id = ?
            ", [$user_id]);

            sendResponse(200, 'پروفایل کاربر دریافت شد', ['user' => $user]);
        }

        // Search users
        if ($_GET['action'] === 'search' && isset($_GET['query'])) {
            $query = '%' . $_GET['query'] . '%';
            $users = $db->fetchAll("
                SELECT id, username, name, avatar, role, online, last_seen 
                FROM users 
                WHERE (username LIKE ? OR name LIKE ?) AND id != ? 
                LIMIT 20
            ", [$query, $query, $user_id]);

            sendResponse(200, 'جستجو انجام شد', ['users' => $users]);
        }

        // Get online users
        if ($_GET['action'] === 'online') {
            $online_users = $db->fetchAll("
                SELECT id, username, name, avatar, role, last_seen 
                FROM users 
                WHERE online = 1 AND id != ? 
                ORDER BY name
            ", [$user_id]);

            sendResponse(200, 'کاربران آنلاین دریافت شد', ['users' => $online_users]);
        }

        // Get user by ID
        if ($_GET['action'] === 'profile' && isset($_GET['user_id'])) {
            $target_user_id = $_GET['user_id'];
            $user = $db->fetch("
                SELECT id, username, name, avatar, role, online, last_seen, created_at 
                FROM users WHERE id = ?
            ", [$target_user_id]);

            if (!$user) {
                sendResponse(404, 'کاربر یافت نشد');
            }

            sendResponse(200, 'پروفایل کاربر دریافت شد', ['user' => $user]);
        }
        break;

    case 'PUT':
        // Update user profile
        $input = json_decode(file_get_contents('php://input'), true);
        
        $update_fields = [];
        $params = [];

        if (isset($input['name'])) {
            $update_fields[] = "name = ?";
            $params[] = $input['name'];
        }

        if (isset($input['avatar'])) {
            $update_fields[] = "avatar = ?";
            $params[] = $input['avatar'];
        }

        if (empty($update_fields)) {
            sendResponse(400, 'هیچ فیلدی برای به‌روزرسانی ارسال نشده است');
        }

        $params[] = $user_id;
        $sql = "UPDATE users SET " . implode(', ', $update_fields) . ", updated_at = NOW() WHERE id = ?";
        $db->query($sql, $params);

        // Get updated user
        $updated_user = $db->fetch("
            SELECT id, username, name, avatar, role, online, last_seen 
            FROM users WHERE id = ?
        ", [$user_id]);

        sendResponse(200, 'پروفایل با موفقیت به‌روزرسانی شد', ['user' => $updated_user]);
        break;

    case 'POST':
        // Add user to group (invite)
        if (isset($_GET['action']) && $_GET['action'] === 'invite') {
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($input['group_id']) || !isset($input['user_id'])) {
                sendResponse(400, 'شناسه گروه و کاربر الزامی است');
            }

            // Check if current user can invite to group
            $current_member = $db->fetch("
                SELECT role FROM group_members 
                WHERE group_id = ? AND user_id = ? AND role IN ('owner', 'admin')
            ", [$input['group_id'], $user_id]);

            if (!$current_member) {
                sendResponse(403, 'شما دسترسی لازم برای دعوت کاربر به گروه را ندارید');
            }

            // Check if target user exists
            $target_user = $db->fetch("SELECT id FROM users WHERE id = ?", [$input['user_id']]);
            if (!$target_user) {
                sendResponse(404, 'کاربر مورد نظر یافت نشد');
            }

            // Check if user is already in group
            $existing_member = $db->fetch("
                SELECT id FROM group_members 
                WHERE group_id = ? AND user_id = ?
            ", [$input['group_id'], $input['user_id']]);

            if ($existing_member) {
                sendResponse(400, 'کاربر قبلاً در این گروه عضو است');
            }

            // Add user to group
            $db->query("
                INSERT INTO group_members (group_id, user_id, role) 
                VALUES (?, ?, 'member')
            ", [$input['group_id'], $input['user_id']]);

            sendResponse(200, 'کاربر با موفقیت به گروه اضافه شد');
        }
        break;

    default:
        sendResponse(405, 'Method مجاز نیست');
}
?>