<?php
class FileUpload {
    private $allowedImageTypes = ['jpg', 'jpeg', 'png', 'gif'];
    private $allowedVideoTypes = ['mp4', 'mov', 'avi'];
    private $allowedAudioTypes = ['mp3', 'wav', 'ogg'];
    private $maxFileSize = 10485760; // 10MB

    public function handleUpload($file) {
        // Check file size
        if ($file['size'] > $this->maxFileSize) {
            return ['success' => false, 'message' => 'حجم فایل بیش از حد مجاز است'];
        }

        // Get file extension
        $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        // Determine file type and folder
        if (in_array($fileExtension, $this->allowedImageTypes)) {
            $type = 'image';
            $folder = 'images/';
        } elseif (in_array($fileExtension, $this->allowedVideoTypes)) {
            $type = 'video';
            $folder = 'videos/';
        } elseif (in_array($fileExtension, $this->allowedAudioTypes)) {
            $type = 'audio';
            $folder = 'audio/';
        } else {
            $type = 'file';
            $folder = 'documents/';
        }

        // Create directory if not exists
        $uploadDir = UPLOAD_PATH . $folder;
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        // Generate unique filename
        $filename = sanitizeFileName($file['name']);
        $filePath = $uploadDir . $filename;

        // Move uploaded file
        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            return [
                'success' => true,
                'file_url' => '/uploads/' . $folder . $filename,
                'file_name' => $file['name'],
                'file_size' => formatFileSize($file['size']),
                'type' => $type
            ];
        } else {
            return ['success' => false, 'message' => 'خطا در آپلود فایل'];
        }
    }
}
?>