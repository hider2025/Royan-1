<?php
require_once 'database.php';
require_once __DIR__ . '/../config.php'; // اضافه کردن این خط

class Auth {
    private $db;

    public function __construct() {
        $this->db = (new Database())->getConnection();
    }

    public function register($username, $name, $email, $password) {
        // Check if user exists
        $check_sql = "SELECT id FROM users WHERE username = ? OR email = ?";
        $existing = $this->db->fetch($check_sql, [$username, $email]);
        
        if ($existing) {
            return ['success' => false, 'message' => 'کاربر با این ایمیل یا نام کاربری وجود دارد'];
        }

        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert user
        $sql = "INSERT INTO users (username, name, email, password, created_at) VALUES (?, ?, ?, ?, NOW())";
        $this->db->query($sql, [$username, $name, $email, $hashed_password]);
        
        $user_id = $this->db->lastInsertId();

        // Generate JWT token
        $token = $this->generateToken($user_id);

        return [
            'success' => true,
            'token' => $token,
            'user' => [
                'id' => $user_id,
                'username' => $username,
                'name' => $name,
                'avatar' => null,
                'role' => 'user'
            ]
        ];
    }

    public function login($username, $password) {
        $sql = "SELECT * FROM users WHERE username = ?";
        $user = $this->db->fetch($sql, [$username]);

        if (!$user || !password_verify($password, $user['password'])) {
            return ['success' => false, 'message' => 'نام کاربری یا رمز عبور اشتباه است'];
        }

        // Update online status
        $this->db->query("UPDATE users SET online = 1, last_seen = NOW() WHERE id = ?", [$user['id']]);

        // Generate token
        $token = $this->generateToken($user['id']);

        return [
            'success' => true,
            'token' => $token,
            'user' => [
                'id' => $user['id'],
                'username' => $user['username'],
                'name' => $user['name'],
                'avatar' => $user['avatar'],
                'role' => $user['role'],
                'online' => true
            ]
        ];
    }

    public function verifyToken($token) {
        try {
            $parts = explode('.', $token);
            if (count($parts) != 3) return false;
            
            list($header, $payload, $signature) = $parts;
            
            $validSignature = hash_hmac('sha256', $header . "." . $payload, JWT_SECRET, true);
            $validSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($validSignature));
            
            if ($signature !== $validSignature) return false;
            
            $payloadData = json_decode(base64_decode($payload), true);
            if (isset($payloadData['exp']) && $payloadData['exp'] < time()) return false;
            
            return $payloadData['user_id'] ?? false;
        } catch (Exception $e) {
            return false;
        }
    }

    public function getUser($user_id) {
        $sql = "SELECT id, username, name, avatar, role, online, last_seen FROM users WHERE id = ?";
        return $this->db->fetch($sql, [$user_id]);
    }

    private function generateToken($user_id) {
        $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
        $payload = json_encode([
            'user_id' => $user_id,
            'iat' => time(),
            'exp' => time() + (30 * 24 * 60 * 60) // 30 days
        ]);
        
        $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
        $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
        
        $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, JWT_SECRET, true);
        $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
        
        return $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
    }

    public function logout($user_id) {
        $this->db->query("UPDATE users SET online = 0, last_seen = NOW() WHERE id = ?", [$user_id]);
        return ['success' => true, 'message' => 'با موفقیت خارج شدید'];
    }
}
?>