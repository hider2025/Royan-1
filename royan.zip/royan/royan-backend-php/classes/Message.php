<?php
namespace Royan;

class Message {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }

    public function create($group_id, $sender_id, $content, $type = 'text', $file_url = null, $file_name = null, $file_size = null, $duration = null) {
        // Check if user is member of the group
        $member_check = $this->db->fetch(
            "SELECT id FROM group_members WHERE group_id = ? AND user_id = ?",
            [$group_id, $sender_id]
        );

        if (!$member_check) {
            return ['success' => false, 'message' => 'شما عضو این گروه نیستید'];
        }

        $sql = "INSERT INTO messages (group_id, sender_id, content, type, file_url, file_name, file_size, duration, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $this->db->query($sql, [
            $group_id,
            $sender_id,
            $content,
            $type,
            $file_url,
            $file_name,
            $file_size,
            $duration
        ]);

        $message_id = $this->db->lastInsertId();

        // Get the created message with user info
        $message = $this->db->fetch("
            SELECT m.*, u.username, u.name, u.avatar, u.role 
            FROM messages m 
            JOIN users u ON m.sender_id = u.id 
            WHERE m.id = ?
        ", [$message_id]);

        return [
            'success' => true,
            'message' => $message
        ];
    }

    public function getByGroup($group_id, $user_id, $page = 1, $limit = 50) {
        // Check if user is member of the group
        $member_check = $this->db->fetch(
            "SELECT id FROM group_members WHERE group_id = ? AND user_id = ?",
            [$group_id, $user_id]
        );

        if (!$member_check) {
            return ['success' => false, 'message' => 'شما عضو این گروه نیستید'];
        }

        $offset = ($page - 1) * $limit;

        // Get messages
        $messages = $this->db->fetchAll("
            SELECT m.*, u.username, u.name, u.avatar, u.role 
            FROM messages m 
            JOIN users u ON m.sender_id = u.id 
            WHERE m.group_id = ? AND m.deleted = 0 
            ORDER BY m.created_at DESC 
            LIMIT ? OFFSET ?
        ", [$group_id, $limit, $offset]);

        // Get total count
        $total = $this->db->fetch("SELECT COUNT(*) as count FROM messages WHERE group_id = ? AND deleted = 0", [$group_id]);

        return [
            'success' => true,
            'messages' => array_reverse($messages), // Return in chronological order
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => $total['count'],
                'pages' => ceil($total['count'] / $limit)
            ]
        ];
    }

    public function getById($message_id) {
        $sql = "SELECT m.*, u.username, u.name, u.avatar, u.role 
                FROM messages m 
                JOIN users u ON m.sender_id = u.id 
                WHERE m.id = ?";
        return $this->db->fetch($sql, [$message_id]);
    }

    public function update($message_id, $user_id, $content) {
        // Check if user owns the message
        $message = $this->db->fetch(
            "SELECT id FROM messages WHERE id = ? AND sender_id = ? AND deleted = 0",
            [$message_id, $user_id]
        );

        if (!$message) {
            return ['success' => false, 'message' => 'پیام یافت نشد'];
        }

        $sql = "UPDATE messages SET content = ?, edited = 1, updated_at = NOW() WHERE id = ?";
        $this->db->query($sql, [$content, $message_id]);

        // Get updated message
        $updated_message = $this->getById($message_id);

        return [
            'success' => true,
            'message' => $updated_message
        ];
    }

    public function delete($message_id, $user_id) {
        // Check if user owns the message or is admin
        $message = $this->db->fetch("
            SELECT m.*, u.role 
            FROM messages m 
            JOIN users u ON m.sender_id = u.id 
            WHERE m.id = ? AND (m.sender_id = ? OR u.role = 'admin')
        ", [$message_id, $user_id]);

        if (!$message) {
            return ['success' => false, 'message' => 'پیام یافت نشد'];
        }

        // Soft delete
        $this->db->query("UPDATE messages SET deleted = 1, updated_at = NOW() WHERE id = ?", [$message_id]);

        return ['success' => true, 'message' => 'پیام حذف شد'];
    }

    public function addReaction($message_id, $user_id, $emoji) {
        // Check if message exists and user can react
        $message = $this->db->fetch(
            "SELECT group_id FROM messages WHERE id = ? AND deleted = 0",
            [$message_id]
        );

        if (!$message) {
            return ['success' => false, 'message' => 'پیام یافت نشد'];
        }

        // Check if user is member of the group
        $member_check = $this->db->fetch(
            "SELECT id FROM group_members WHERE group_id = ? AND user_id = ?",
            [$message['group_id'], $user_id]
        );

        if (!$member_check) {
            return ['success' => false, 'message' => 'شما عضو این گروه نیستید'];
        }

        // Remove existing reaction from this user
        $this->db->query("
            UPDATE messages 
            SET reactions = JSON_REMOVE(reactions, JSON_UNQUOTE(JSON_SEARCH(reactions, 'one', ?))) 
            WHERE id = ? AND JSON_SEARCH(reactions, 'one', ?) IS NOT NULL
        ", [$user_id, $message_id, $user_id]);

        // Add new reaction
        $reaction = json_encode(['user_id' => $user_id, 'emoji' => $emoji]);
        $this->db->query("
            UPDATE messages 
            SET reactions = JSON_MERGE_PATCH(COALESCE(reactions, '[]'), ?) 
            WHERE id = ?
        ", [$reaction, $message_id]);

        return ['success' => true, 'message' => 'واکنش اضافه شد'];
    }

    public function getReactions($message_id) {
        $message = $this->db->fetch("
            SELECT reactions 
            FROM messages 
            WHERE id = ? AND deleted = 0
        ", [$message_id]);

        if (!$message || empty($message['reactions'])) {
            return [];
        }

        return json_decode($message['reactions'], true);
    }

    public function searchInGroup($group_id, $user_id, $query) {
        // Check if user is member of the group
        $member_check = $this->db->fetch(
            "SELECT id FROM group_members WHERE group_id = ? AND user_id = ?",
            [$group_id, $user_id]
        );

        if (!$member_check) {
            return ['success' => false, 'message' => 'شما عضو این گروه نیستید'];
        }

        $search_query = "%$query%";
        $messages = $this->db->fetchAll("
            SELECT m.*, u.username, u.name, u.avatar, u.role 
            FROM messages m 
            JOIN users u ON m.sender_id = u.id 
            WHERE m.group_id = ? AND m.deleted = 0 AND m.content LIKE ? 
            ORDER BY m.created_at DESC 
            LIMIT 50
        ", [$group_id, $search_query]);

        return [
            'success' => true,
            'messages' => $messages
        ];
    }
}
?>