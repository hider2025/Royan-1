<?php
namespace Royan;

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\WebSocket\WsServer;
use Ratchet\Http\HttpServer;
use Ratchet\Server\IoServer;

class WebSocketServer implements MessageComponentInterface {
    protected $clients;
    protected $users;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->users = [];
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        echo "New connection! ({$conn->resourceId})\n";
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        echo "Message from {$from->resourceId}: {$msg}\n";
        
        $data = json_decode($msg, true);
        
        if (!$data || !isset($data['type'])) {
            return;
        }

        switch ($data['type']) {
            case 'auth':
                $this->handleAuth($from, $data);
                break;
                
            case 'join_group':
                $this->handleJoinGroup($from, $data);
                break;
                
            case 'send_message':
                $this->handleSendMessage($from, $data);
                break;
                
            case 'typing':
                $this->handleTyping($from, $data);
                break;
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
        
        // Remove user from users list
        foreach ($this->users as $userId => $userConn) {
            if ($userConn === $conn) {
                unset($this->users[$userId]);
                
                // Notify others about user going offline
                $this->broadcast([
                    'type' => 'user_offline',
                    'user_id' => $userId
                ]);
                
                break;
            }
        }
        
        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }

    private function handleAuth($from, $data) {
        if (!isset($data['token']) || !isset($data['user_id'])) {
            return;
        }

        // Verify token (in real implementation, verify JWT token)
        $this->users[$data['user_id']] = $from;
        
        // Store user ID in connection
        $from->user_id = $data['user_id'];
        
        // Notify others about user coming online
        $this->broadcast([
            'type' => 'user_online',
            'user_id' => $data['user_id']
        ], $from);
        
        $from->send(json_encode([
            'type' => 'auth_success',
            'message' => 'احراز هویت موفقیت‌آمیز بود'
        ]));
    }

    private function handleJoinGroup($from, $data) {
        if (!isset($data['group_id']) || !isset($from->user_id)) {
            return;
        }

        // Join group room
        $from->group_id = $data['group_id'];
        
        $from->send(json_encode([
            'type' => 'joined_group',
            'group_id' => $data['group_id'],
            'message' => 'به گروه پیوستید'
        ]));
    }

    private function handleSendMessage($from, $data) {
        if (!isset($data['group_id']) || !isset($data['message']) || !isset($from->user_id)) {
            return;
        }

        $messageData = [
            'type' => 'new_message',
            'group_id' => $data['group_id'],
            'message' => $data['message'],
            'user_id' => $from->user_id,
            'timestamp' => date('Y-m-d H:i:s')
        ];

        // Broadcast to all clients in the same group
        $this->broadcastToGroup($data['group_id'], $messageData, $from);
    }

    private function handleTyping($from, $data) {
        if (!isset($data['group_id']) || !isset($from->user_id)) {
            return;
        }

        $typingData = [
            'type' => 'user_typing',
            'group_id' => $data['group_id'],
            'user_id' => $from->user_id,
            'typing' => $data['typing'] ?? true
        ];

        $this->broadcastToGroup($data['group_id'], $typingData, $from);
    }

    private function broadcast($data, $excludeSender = null) {
        $jsonData = json_encode($data);
        
        foreach ($this->clients as $client) {
            if ($excludeSender !== $client) {
                $client->send($jsonData);
            }
        }
    }

    private function broadcastToGroup($group_id, $data, $excludeSender = null) {
        $jsonData = json_encode($data);
        
        foreach ($this->clients as $client) {
            if (isset($client->group_id) && $client->group_id == $group_id && $excludeSender !== $client) {
                $client->send($jsonData);
            }
        }
    }

    public static function run() {
        $port = 8080;
        $server = IoServer::factory(
            new HttpServer(
                new WsServer(
                    new WebSocketServer()
                )
            ),
            $port
        );

        echo "WebSocket server running on port {$port}\n";
        $server->run();
    }
}

// Run server if executed directly
if (isset($argv[1]) && $argv[1] === 'run') {
    WebSocketServer::run();
}
?>