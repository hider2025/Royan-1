<?php
namespace Royan;

class User {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }

    public function create($username, $name, $email, $password, $avatar = null, $role = 'user') {
        // Check if user exists
        $check_sql = "SELECT id FROM users WHERE username = ? OR email = ?";
        $existing = $this->db->fetch($check_sql, [$username, $email]);
        
        if ($existing) {
            return ['success' => false, 'message' => 'کاربر با این ایمیل یا نام کاربری وجود دارد'];
        }

        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert user
        $sql = "INSERT INTO users (username, name, email, password, avatar, role, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, NOW())";
        $this->db->query($sql, [$username, $name, $email, $hashed_password, $avatar, $role]);
        
        $user_id = $this->db->lastInsertId();

        return [
            'success' => true,
            'user_id' => $user_id
        ];
    }

    public function getById($user_id) {
        $sql = "SELECT id, username, name, email, avatar, role, online, last_seen, created_at 
                FROM users WHERE id = ?";
        return $this->db->fetch($sql, [$user_id]);
    }

    public function getByUsername($username) {
        $sql = "SELECT id, username, name, email, avatar, role, online, last_seen, created_at 
                FROM users WHERE username = ?";
        return $this->db->fetch($sql, [$username]);
    }

    public function verifyPassword($username, $password) {
        $sql = "SELECT id, password FROM users WHERE username = ?";
        $user = $this->db->fetch($sql, [$username]);
        
        if (!$user) {
            return ['success' => false, 'message' => 'کاربر یافت نشد'];
        }

        if (!password_verify($password, $user['password'])) {
            return ['success' => false, 'message' => 'رمز عبور اشتباه است'];
        }

        return ['success' => true, 'user_id' => $user['id']];
    }

    public function updateOnlineStatus($user_id, $online) {
        $sql = "UPDATE users SET online = ?, last_seen = NOW() WHERE id = ?";
        $this->db->query($sql, [$online, $user_id]);
        return ['success' => true];
    }

    public function updateProfile($user_id, $data) {
        $allowed_fields = ['name', 'avatar', 'email'];
        $update_fields = [];
        $params = [];

        foreach ($data as $field => $value) {
            if (in_array($field, $allowed_fields)) {
                $update_fields[] = "$field = ?";
                $params[] = $value;
            }
        }

        if (empty($update_fields)) {
            return ['success' => false, 'message' => 'هیچ فیلد معتبری برای به‌روزرسانی وجود ندارد'];
        }

        $params[] = $user_id;
        $sql = "UPDATE users SET " . implode(', ', $update_fields) . ", updated_at = NOW() WHERE id = ?";
        $this->db->query($sql, $params);

        return ['success' => true];
    }

    public function search($query, $exclude_user_id = null) {
        $sql = "SELECT id, username, name, avatar, role, online, last_seen 
                FROM users 
                WHERE (username LIKE ? OR name LIKE ?)";
        
        $params = ["%$query%", "%$query%"];
        
        if ($exclude_user_id) {
            $sql .= " AND id != ?";
            $params[] = $exclude_user_id;
        }

        $sql .= " LIMIT 20";

        return $this->db->fetchAll($sql, $params);
    }

    public function getOnlineUsers($exclude_user_id = null) {
        $sql = "SELECT id, username, name, avatar, role, last_seen 
                FROM users 
                WHERE online = 1";
        
        $params = [];
        
        if ($exclude_user_id) {
            $sql .= " AND id != ?";
            $params[] = $exclude_user_id;
        }

        $sql .= " ORDER BY name";

        return $this->db->fetchAll($sql, $params);
    }

    public function changeRole($user_id, $new_role) {
        $allowed_roles = ['user', 'admin'];
        if (!in_array($new_role, $allowed_roles)) {
            return ['success' => false, 'message' => 'نقش معتبر نیست'];
        }

        $sql = "UPDATE users SET role = ?, updated_at = NOW() WHERE id = ?";
        $this->db->query($sql, [$new_role, $user_id]);

        return ['success' => true, 'message' => 'نقش کاربر به‌روزرسانی شد'];
    }

    public function delete($user_id) {
        // Note: In production, you might want to soft delete
        $sql = "DELETE FROM users WHERE id = ?";
        $this->db->query($sql, [$user_id]);

        return ['success' => true, 'message' => 'کاربر حذف شد'];
    }
}
?>