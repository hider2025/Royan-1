<?php
namespace Royan;

class Group {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }

    public function create($name, $created_by, $description = null, $avatar = null, $is_public = true, $settings = null) {
        $sql = "INSERT INTO groups (name, description, avatar, created_by, is_public, settings, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, NOW())";
        
        $default_settings = json_encode([
            'allowInvites' => true,
            'allowFileSharing' => true,
            'allowVoiceMessages' => true
        ]);

        $this->db->query($sql, [
            $name,
            $description,
            $avatar,
            $created_by,
            $is_public,
            $settings ?: $default_settings
        ]);

        $group_id = $this->db->lastInsertId();

        // Add creator as owner
        $this->addMember($group_id, $created_by, 'owner');

        return [
            'success' => true,
            'group_id' => $group_id
        ];
    }

    public function getById($group_id) {
        $sql = "SELECT g.*, u.username as created_by_username 
                FROM groups g 
                JOIN users u ON g.created_by = u.id 
                WHERE g.id = ?";
        return $this->db->fetch($sql, [$group_id]);
    }

    public function getUserGroups($user_id) {
        $sql = "SELECT g.*, gm.role, u.username as created_by_username 
                FROM groups g 
                JOIN group_members gm ON g.id = gm.group_id 
                JOIN users u ON g.created_by = u.id 
                WHERE gm.user_id = ? 
                ORDER BY g.created_at DESC";
        return $this->db->fetchAll($sql, [$user_id]);
    }

    public function update($group_id, $user_id, $data) {
        // Check if user is owner/admin of the group
        $member = $this->db->fetch("
            SELECT role FROM group_members 
            WHERE group_id = ? AND user_id = ? AND role IN ('owner', 'admin')
        ", [$group_id, $user_id]);

        if (!$member) {
            return ['success' => false, 'message' => 'شما دسترسی لازم برای ویرایش این گروه را ندارید'];
        }

        $allowed_fields = ['name', 'description', 'avatar', 'settings'];
        $update_fields = [];
        $params = [];

        foreach ($data as $field => $value) {
            if (in_array($field, $allowed_fields)) {
                $update_fields[] = "$field = ?";
                
                if ($field === 'settings') {
                    $params[] = json_encode($value);
                } else {
                    $params[] = $value;
                }
            }
        }

        if (empty($update_fields)) {
            return ['success' => false, 'message' => 'هیچ فیلدی برای به‌روزرسانی ارسال نشده است'];
        }

        $params[] = $group_id;
        $sql = "UPDATE groups SET " . implode(', ', $update_fields) . ", updated_at = NOW() WHERE id = ?";
        $this->db->query($sql, $params);

        return ['success' => true, 'message' => 'گروه با موفقیت به‌روزرسانی شد'];
    }

    public function delete($group_id, $user_id) {
        // Check if user is owner of the group
        $member = $this->db->fetch("
            SELECT role FROM group_members 
            WHERE group_id = ? AND user_id = ? AND role = 'owner'
        ", [$group_id, $user_id]);

        if (!$member) {
            return ['success' => false, 'message' => 'فقط سازنده گروه می‌تواند آن را حذف کند'];
        }

        $this->db->query("DELETE FROM groups WHERE id = ?", [$group_id]);
        return ['success' => true, 'message' => 'گروه با موفقیت حذف شد'];
    }

    public function addMember($group_id, $user_id, $role = 'member') {
        // Check if user is already in group
        $existing_member = $this->db->fetch("
            SELECT id FROM group_members 
            WHERE group_id = ? AND user_id = ?
        ", [$group_id, $user_id]);

        if ($existing_member) {
            return ['success' => false, 'message' => 'کاربر قبلاً در این گروه عضو است'];
        }

        $sql = "INSERT INTO group_members (group_id, user_id, role, joined_at) VALUES (?, ?, ?, NOW())";
        $this->db->query($sql, [$group_id, $user_id, $role]);

        return ['success' => true, 'message' => 'کاربر به گروه اضافه شد'];
    }

    public function removeMember($group_id, $user_id, $remover_id) {
        // Check if remover has permission (owner/admin) or is removing themselves
        if ($user_id != $remover_id) {
            $remover_role = $this->db->fetch("
                SELECT role FROM group_members 
                WHERE group_id = ? AND user_id = ?
            ", [$group_id, $remover_id]);

            if (!$remover_role || !in_array($remover_role['role'], ['owner', 'admin'])) {
                return ['success' => false, 'message' => 'شما دسترسی لازم برای حذف کاربر را ندارید'];
            }

            // Prevent removing owners
            $target_role = $this->db->fetch("
                SELECT role FROM group_members 
                WHERE group_id = ? AND user_id = ?
            ", [$group_id, $user_id]);

            if ($target_role && $target_role['role'] === 'owner') {
                return ['success' => false, 'message' => 'نمی‌توانید سازنده گروه را حذف کنید'];
            }
        }

        $this->db->query("DELETE FROM group_members WHERE group_id = ? AND user_id = ?", [$group_id, $user_id]);
        return ['success' => true, 'message' => 'کاربر از گروه حذف شد'];
    }

    public function getMembers($group_id) {
        $sql = "SELECT u.id, u.username, u.name, u.avatar, u.role, u.online, 
                       gm.role as group_role, gm.joined_at 
                FROM group_members gm 
                JOIN users u ON gm.user_id = u.id 
                WHERE gm.group_id = ? 
                ORDER BY 
                    CASE gm.role 
                        WHEN 'owner' THEN 1 
                        WHEN 'admin' THEN 2 
                        ELSE 3 
                    END,
                    gm.joined_at";
        return $this->db->fetchAll($sql, [$group_id]);
    }

    public function updateMemberRole($group_id, $user_id, $new_role, $changer_id) {
        // Check if changer has permission (owner only for role changes)
        $changer_role = $this->db->fetch("
            SELECT role FROM group_members 
            WHERE group_id = ? AND user_id = ?
        ", [$group_id, $changer_id]);

        if (!$changer_role || $changer_role['role'] !== 'owner') {
            return ['success' => false, 'message' => 'فقط سازنده گروه می‌تواند نقش کاربران را تغییر دهد'];
        }

        $allowed_roles = ['member', 'admin'];
        if (!in_array($new_role, $allowed_roles)) {
            return ['success' => false, 'message' => 'نقش معتبر نیست'];
        }

        $this->db->query("
            UPDATE group_members 
            SET role = ? 
            WHERE group_id = ? AND user_id = ?
        ", [$new_role, $group_id, $user_id]);

        return ['success' => true, 'message' => 'نقش کاربر به‌روزرسانی شد'];
    }

    public function isMember($group_id, $user_id) {
        $sql = "SELECT id FROM group_members WHERE group_id = ? AND user_id = ?";
        $result = $this->db->fetch($sql, [$group_id, $user_id]);
        return $result !== false;
    }

    public function getMemberRole($group_id, $user_id) {
        $sql = "SELECT role FROM group_members WHERE group_id = ? AND user_id = ?";
        $result = $this->db->fetch($sql, [$group_id, $user_id]);
        return $result ? $result['role'] : null;
    }
}
?>