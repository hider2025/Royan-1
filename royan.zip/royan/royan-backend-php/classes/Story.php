<?php
namespace Royan;

class Story {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }

    public function create($user_id, $media_url, $expires_in_hours = 24) {
        $expires_at = date('Y-m-d H:i:s', strtotime("+{$expires_in_hours} hours"));

        $sql = "INSERT INTO stories (user_id, media_url, expires_at, created_at) 
                VALUES (?, ?, ?, NOW())";
        
        $this->db->query($sql, [$user_id, $media_url, $expires_at]);

        $story_id = $this->db->lastInsertId();

        return [
            'success' => true,
            'story_id' => $story_id
        ];
    }

    public function getActiveStories() {
        $sql = "SELECT s.*, u.username, u.name, u.avatar 
                FROM stories s 
                JOIN users u ON s.user_id = u.id 
                WHERE s.expires_at > NOW() 
                ORDER BY s.created_at DESC";

        $stories = $this->db->fetchAll($sql);

        // Group stories by user
        $grouped_stories = [];
        foreach ($stories as $story) {
            $user_id = $story['user_id'];
            if (!isset($grouped_stories[$user_id])) {
                $grouped_stories[$user_id] = [
                    'user' => [
                        'id' => $story['user_id'],
                        'username' => $story['username'],
                        'name' => $story['name'],
                        'avatar' => $story['avatar']
                    ],
                    'stories' => []
                ];
            }
            $grouped_stories[$user_id]['stories'][] = [
                'id' => $story['id'],
                'media_url' => $story['media_url'],
                'created_at' => $story['created_at'],
                'expires_at' => $story['expires_at']
            ];
        }

        return array_values($grouped_stories);
    }

    public function getUserStories($user_id) {
        $sql = "SELECT s.*, u.username, u.name, u.avatar 
                FROM stories s 
                JOIN users u ON s.user_id = u.id 
                WHERE s.user_id = ? AND s.expires_at > NOW() 
                ORDER BY s.created_at DESC";

        return $this->db->fetchAll($sql, [$user_id]);
    }

    public function getById($story_id) {
        $sql = "SELECT s.*, u.username, u.name, u.avatar 
                FROM stories s 
                JOIN users u ON s.user_id = u.id 
                WHERE s.id = ?";
        return $this->db->fetch($sql, [$story_id]);
    }

    public function delete($story_id, $user_id) {
        // Check if user owns the story
        $story = $this->db->fetch("
            SELECT id FROM stories 
            WHERE id = ? AND user_id = ?
        ", [$story_id, $user_id]);

        if (!$story) {
            return ['success' => false, 'message' => 'استوری یافت نشد'];
        }

        $this->db->query("DELETE FROM stories WHERE id = ?", [$story_id]);
        return ['success' => true, 'message' => 'استوری حذف شد'];
    }

    public function deleteExpiredStories() {
        $sql = "DELETE FROM stories WHERE expires_at <= NOW()";
        $result = $this->db->query($sql);
        
        return [
            'success' => true,
            'deleted_count' => $result->rowCount()
        ];
    }

    public function getStoryViews($story_id) {
        // This would require a story_views table
        // For now, return empty array
        return [];
    }

    public function addView($story_id, $user_id) {
        // This would require a story_views table
        // For now, just return success
        return ['success' => true];
    }

    public function getActiveCountByUser($user_id) {
        $sql = "SELECT COUNT(*) as count 
                FROM stories 
                WHERE user_id = ? AND expires_at > NOW()";
        $result = $this->db->fetch($sql, [$user_id]);
        return $result['count'];
    }

    public function canUserPostStory($user_id) {
        // Limit number of active stories per user (e.g., max 10)
        $active_count = $this->getActiveCountByUser($user_id);
        return $active_count < 10;
    }
}
?>